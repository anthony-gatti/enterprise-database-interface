package proj.pack;

public class Amenity {

}
